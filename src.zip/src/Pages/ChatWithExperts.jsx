import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { Row, Col, Table } from 'react-bootstrap';
import { FaWhatsapp, FaFacebook, FaInstagram, FaTwitter, FaInfoCircle } from 'react-icons/fa';
import MentalHealthForm from '../Components/MentalHealthForm';
import { authContext } from '../Context';


import {
  Typography,
  Button,

} from '@mui/material';
import ExpertLoginForm from '../Components/ExpertLogin';

// import './ChatWithExperts.css'; // Import custom CSS file

function ChatWithExperts() {

  const userData = useContext(authContext);
  const { user } = userData;
  const [isShare, setIsShare] = useState(false);
  const [problemData, setProblemData] = useState([])

  const handleFormSubmit = async (formData) => {
    try {
      const response = await axios.post('http://localhost:5001/submit', formData);
      console.log('the form data ', response.data);
      alert('successfully submited.....!');
      setIsShare(false)
    } catch (error) {
      console.error('Error submitting form data:', error);
    }
  };

  const experts = [
    {
      name: 'Dr. John Smith',
      profilePic: 'https://picsum.photos/id/1018/50/50', // Reduced profile pic size
      designation: 'Clinical Psychologist',
      address: '123 Main St, Anytown USA',
      whatsapp: 'https://wa.me/123456789',
      facebook: 'https://www.facebook.com/drjohnsmith',
      instagram: 'https://www.instagram.com/drjohnsmith',
      twitter: 'https://www.twitter.com/drjohnsmith',
      userId: 'doctor1',
      password: 'password'
    },
    {
      name: 'Dr. Jane Doe',
      profilePic: 'https://picsum.photos/id/1025/50/50', // Reduced profile pic size
      designation: 'Counseling Psychologist',
      address: '456 Oak St, Anytown USA',
      whatsapp: 'https://wa.me/987654321',
      facebook: 'https://www.facebook.com/drjanedoe',
      instagram: 'https://www.instagram.com/drjanedoe',
      twitter: 'https://www.twitter.com/drjanedoe',
      userId: 'doctor2',
      password: 'password'
    },
  ];
 
  const fetchRecommendations = async (email) => {
    try {
      const response = await axios.get(`http://localhost:5001/recommendations/${email}`);
      const recommendations = response.data.recommendations;
      // Use the 'recommendations' array to display or process the data on the frontend.
      setProblemData(recommendations);
      console.log(recommendations);
    } catch (error) {
      console.error('Error fetching recommendations:', error);
    }
  };
  useEffect(() => {





    // Example: Fetch recommendations for a student with email 'example@student.com'
    fetchRecommendations(user.userEmail);



  }, []);

  return (
    <>

      <div style={{ background: '#f0f0f0', textAlign: 'center', padding: '1rem', color: 'blue' }}>

      
        <Typography variant="body1" align="jsutify" style={{ marginBottom: '1rem', }}>
        We understand that navigating through academic and personal challenges can be overwhelming, and we are here to lend a helping hand. Whether you're struggling with stress, anxiety, depression, or any other mental health issue, you can freely share your thoughts and feelings with the community.
        </Typography>

        <Button
          variant="contained"
          color="primary"

          onClick={() => setIsShare(!isShare)}
          style={{ marginTop: '1rem', marginBottom: '2rem', boxShadow: 'none', }}
        >
          {isShare ? 'hide form' : 'Share Your Problems With Experts  -Click here'}
        </Button>

        {/* Rest of the form code */}
      </div>
      {problemData.length !== 0 && (
        <div>
          <h5>Experts recommendations...</h5>
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>Problem Type</th>
                <th>Problem Details</th>
                <th>Recommendation</th>
              </tr>
            </thead>
            <tbody>
              {problemData.map((problem, index) => (
                <tr key={index}>
                  <td>{problem.problemType}</td>
                  <td>{problem.details}</td>
                  <td>{problem.recommendation}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}


      {isShare && (<Row className="justify-content-center">
        <Col xs={12} sm={10} md={8} lg={6}>
          <MentalHealthForm onFormSubmit={handleFormSubmit} />
        </Col>
      </Row>)}
      <Row className="justify-content-center">
        <Col xs={12} sm={10} md={8} lg={6}>
          <h2 className="text-center my-4">Chat with Experts</h2>
          <Table striped bordered hover responsive>
            <thead>
              <tr>
                <th>Profile Pic</th>
                <th>Name</th>
                <th>Designation</th>
                <th>Address</th>
                <th>WhatsApp</th>
                <th>Facebook</th>
                <th>Instagram</th>
                <th>Twitter</th>
              </tr>
            </thead>
            <tbody>
              {experts.map((expert, index) => (
                <tr key={index}>
                  <td>
                    <img src={expert.profilePic} alt={expert.name} className="profile-pic" />
                  </td>
                  <td>{expert.name}</td>
                  <td>{expert.designation}</td>
                  <td>{expert.address}</td>
                  <td>
                    <a href={expert.whatsapp} target="_blank" rel="noopener noreferrer">
                      <FaWhatsapp />
                    </a>
                  </td>
                  <td>
                    <a href={expert.facebook} target="_blank" rel="noopener noreferrer">
                      <FaFacebook />
                    </a>
                  </td>
                  <td>
                    <a href={expert.instagram} target="_blank" rel="noopener noreferrer">
                      <FaInstagram />
                    </a>
                  </td>
                  <td>
                    <a href={expert.twitter} target="_blank" rel="noopener noreferrer">
                      <FaTwitter />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Col>
      </Row>

    </>
  );
}

export default ChatWithExperts;
