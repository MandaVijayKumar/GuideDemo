
import React, { useEffect, useContext,useState } from "react";
import { auth, provider } from '../Auth/firebase';
import { signInWithPopup, onAuthStateChanged } from "firebase/auth";
import { authContext } from "../Context";
import { useNavigate } from "react-router-dom";
import img23 from '../Asserts/images/23 .jpg'

import ChatBot from 'react-simple-chatbot';
import '../Style/Home.css';
import FAQ from '../Components/FAQ.jsx'

import signin from '../Asserts/images/googlesignin.png';
import { ThemeProvider } from 'styled-components';
import SuicidePreventionButton from '../Components/SuicidePreventionButton';


import { Link } from 'react-router-dom';


import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  root: {
    position: 'absolute',
    top: '6rem',
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: '2.5rem',
    fontWeight: 'bold',
    margin: 0,
    padding: '1.2rem',
    color: theme.palette.text.primary,
    textShadow: '1px 1px 2px rgba(0, 0, 0, 0.2)',
  },
  subtitle: {
    fontSize: '2rem',
    fontWeight: 'normal',
    margin: 0,
    padding: '1.2rem',
    color: theme.palette.text.primary,
    textShadow: '1px 1px 2px rgba(0, 0, 0, 0.2)',
  },
  loginButton: {
    margin: '1.2rem',
    padding: '0.8rem 2.4rem',
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.common.white,
    borderRadius: '2rem',
    fontSize: '1.6rem',
    fontWeight: 'bold',
    textTransform: 'uppercase',
    cursor: 'pointer',
    boxShadow: '1px 1px 2px rgba(0, 0, 0, 0.2)',
    transition: 'background-color 0.3s ease',
    '&:hover': {
      backgroundColor: theme.palette.primary.dark,
    },
  },
}));

function Home() {
  const navigate = useNavigate();
  const authUser = useContext(authContext);
  const { user, setUser } = authUser;
  const [context, setContext] = useState({});

  const handleEnd = ({ steps, values }) => {
    const name = context.name || 'student';
    const problemType = values[2].value || '';
    const problemDescription = context[`${problemType}_problem`] || '';
    const message = `Thank you for reaching out, ${name}. You have selected ${problemType} problem and described it as "${problemDescription}". Our expert will contact you soon.`;
    alert(message);
  };
  console.log(context)

  const googleSignIn = () => {
    signInWithPopup(auth, provider)
      .then((result) => {
        navigate('/psychoarea/introduction');
      }).catch((error) => {
        console.log(error);
      });
  }

  useEffect(() => {
    onAuthStateChanged(auth, (user) => {
      if (user) {
        setUser({
          userName: user.displayName,
          userEmail: user.email,
          userPhoto: user.photoURL
        });
      } else {
        setUser(null);
      }
    });
  }, []);

  const theme = {
    background: '#f5f8fb',
    fontFamily: 'Helvetica Neue',
    headerBgColor: '#EF6C00',
    headerFontColor: '#fff',
    headerFontSize: '15px',
    botBubbleColor: '#EF6C00',
    botFontColor: '#fff',
    userBubbleColor: '#fff',
    userFontColor: '#4a4a4a',
  };
  const [isOpen, setIsOpen] = useState(true);

  const handleClose = () => {
    setIsOpen(false);
  };

  const handleComplete = () => {
    setIsOpen(false);
  };
  
  const steps = [
    {
      id: '1',
      message: 'Hello! What is your name?',
      trigger: '2',
    },
    {
      id: '2',
      user: true,
      trigger: '3',
    },
    {
      id: '3',
      message: 'Hi {previousValue}! How can I assist you today?',
      trigger: '4',
    },
    {
      id: '4',
      options: [
        { value: 'stress', label: 'Stress', trigger: 'stressTechniques' },
        { value: 'anxiety', label: 'Anxiety', trigger: 'anxietyTechniques' },
        { value: 'depression', label: 'Depression', trigger: 'depressionTechniques' },
        // Add more mental health issues as needed
      ],
    },
    {
      id: 'stressTechniques',
      message: 'It seems like you\'re feeling stressed. Have you tried any relaxation techniques like deep breathing or meditation?',
      trigger: 'stressTechniquesOptions',
    },
    {
      id: 'stressTechniquesOptions',
      options: [
        { value: 'yes', label: 'Yes', trigger: 'stressTechniquesYes' },
        { value: 'no', label: 'No', trigger: 'stressTechniquesNo' },
      ],
    },
    {
      id: 'stressTechniquesYes',
      message: 'That\'s great! Regular practice of relaxation techniques can help reduce stress and anxiety. Is there anything else you\'d like to discuss?',
      trigger: 'otherTopics',
    },
    {
      id: 'stressTechniquesNo',
      message: 'No problem. You can consider trying relaxation techniques like deep breathing exercises or mindfulness meditation. Is there anything else you\'d like to talk about?',
      trigger: 'otherTopics',
    },
    {
      id: 'anxietyTechniques',
      message: 'It seems like you\'re experiencing anxiety. Engaging in activities like exercise, journaling, or talking to someone you trust can be helpful. Is there anything else you\'d like to discuss?',
      trigger: 'otherTopics',
    },
    {
      id: 'depressionTechniques',
      message: 'It seems like you\'re feeling depressed. Establishing a routine, engaging in hobbies, or seeking professional help can make a difference. Is there anything else you\'d like to discuss?',
      trigger: 'otherTopics',
    },
    {
      id: 'otherTopics',
      message: 'I\'m here to listen and provide support. Is there anything specific you\'d like to talk about?',
      trigger: '11',
    },
    {
      id: '11',
      user: true,
      trigger: '12',
    },
    {
      id: '12',
      message: 'Thank you for sharing, {previousValue}. It\'s important to talk about your feelings. If you need immediate assistance, consider reaching out to a counselor or helpline. They can provide professional support. Is there anything else I can help you with?',
      trigger: '13',
    },
    {
      id: '13',
      user: true,
      trigger: '14',
    },
    {
      id: '14',
      message: 'Take care of yourself, {previousValue}. Remember, it\'s okay to ask for help when you need it. If you have any further questions or concerns, feel free to reach out anytime. Wishing you all the best!',
      end: true,
    },
    // Additional steps for mental health support
    {
      id: '15',
      message: 'If you are experiencing thoughts of self-harm or suicide, it is essential to seek immediate help. Please consider contacting a helpline or emergency services in your country. You dot have to face this alone.',
      trigger: '16',
    },
    {
      id: '16',
      message: 'Here are some international helpline numbers that may be useful:\n- United States: National Suicide Prevention Lifeline 1-800-273-TALK (1-800-273-8255)\n- United Kingdom: Samaritans 116 123\n- Canada: Crisis Services Canada 1-833-456-4566\n- Australia: Lifeline Australia 13 11 14\n- India: Vandrevala Foundation 1860-2662-345\n- Please search online for helpline numbers in your country.',
      trigger: '17',
    },
    {
      id: '17',
      message: 'Remember, your feelings are valid, and reaching out for help is a sign of strength. Is there anything else I can assist you with?',
      trigger: '13',
    },
  ];
  
  
  const classes = useStyles();
  
  return (
    <>
         <div style={{position:'absolute', top:'4.5rem', right:'1rem'}} >
  <SuicidePreventionButton/>
</div>

       <div className={classes.root}>
      <h1 className={classes.title}>Hello, I'm an AI Counselling Expert System</h1>
      <h2 className={classes.subtitle}>I can help you with your psychological problems.</h2>
      {/* <button className={classes.loginButton}>Login with me to get started!</button> */}
    </div>
   
    <div className='container d-flex justify-content-center align-items-center login'>
       
      <div className=" p-4">
        <h2 className="text-center">Login</h2>
        <div className="d-flex justify-content-center">
          <button onClick={googleSignIn} className="btn btn-primary btn-lg">
            {/* <img src={signin} alt="not found" style={{ width: '50%', height: '50%' }} /> */}
            <span className="ms-3">Sign in with Google</span>
          </button>
        </div>
      </div>
      <div style={{position:'absolute' , top: '4rem', right:'0rem'}}>
      {/* <ThemeProvider theme={theme}>
      <ChatBot
       steps={steps}
       headerTitle="Student Mental Health Support."
       botAvatar={img23}
       floating={true}
       
       width="90%"
       height="80%"
       placeholder="Type your message here..."
       enableMobileAutoFocus={true}
       userAvatar="https://i.imgur.com/vLGwV7O.png"
       cache={false}
       recognitionEnable={true}
       enableSmoothScroll={true}
      speechSynthesis={{ enable: true, lang: 'en' }}
       recognitionLang="en-US"
       recognitionContinuous={true}
       inputTextFieldHint="Type your message here..."
       inputTextFieldName="Type your message here..."
      />
      </ThemeProvider> */}

      </div>
      
     
     
    </div>
    <div>
      <FAQ/>

      </div>
    </>
  );
}

export default Home;



