import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../Style/VirtualTherapist.css';

const VirtualTherapist = () => {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef(null);

  const fetchMessage = async (text) => {
    try {
      const response = await axios.post('http://127.0.0.1:5001/virtualtherapist', { message: text });
      const botMessage = response.data.message;
      setMessages((prevMessages) => [...prevMessages, { role: 'user', content: text }, { role: 'chatbot', content: botMessage }]);
    } catch (error) {
      if (error.response && error.response.status === 429) {
        // If the error is due to rate limiting (status code 429), implement exponential backoff
        console.warn('Rate limit exceeded. Retrying after 2 seconds...');
        await new Promise((resolve) => setTimeout(resolve, 2000)); // Wait for 2 seconds
        fetchMessage(text); // Retry the API request
      } else {
        console.error('Error:', error.message);
      }
    }
  };
  

  const handleMessageSubmit = (e) => {
    e.preventDefault();
    if (inputText.trim() !== '') {
      setMessages((prevMessages) => [...prevMessages, { role: 'user', content: inputText }]);
      fetchMessage(inputText);
      setInputText('');
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
  };

  const handleOptionSelect = (option) => {
    setInputText(option);
    handleMessageSubmit(new Event('submit'));
  };

  return (
    <div className="chatbot mt-5">
      <div className="chat-container">
        <div className="therapist-chat">
          <div className="message message--system">
            Welcome! I am a virtual psychology doctor here to support you. Please share your thoughts or any challenges you are facing, and I will provide guidance.
          </div>
          {messages.map((message, index) => (
            message.role === 'chatbot' && (
              <div key={index} className={`message message--${message.role}`}>
                {message.content}
                {message.choices && (
                  <div className="follow-up-question">
                    <p>{message.question}</p>
                    <div className="follow-up-options">
                      {message.choices.map((choice, i) => (
                        <div key={i} className="follow-up-option" onClick={() => handleOptionSelect(choice)}>
                          {choice}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )
          ))}
        </div>
        <div className="student-chat">
          {messages.map((message, index) => (
            message.role === 'user' && (
              <div key={index} className={`message message--${message.role}`}>
                {message.content}
              </div>
            )
          ))}
        </div>
        <div ref={messagesEndRef} />
      </div>
      <form className="chatbot__form" onSubmit={handleMessageSubmit}>
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Type your message..."
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
};

export default VirtualTherapist;
