

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { makeStyles } from '@material-ui/core/styles';
import {
  Box,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText,
  Typography,
  Button,
} from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  },
  card: {
    maxWidth: 500,
    width: '100%',
    backgroundColor: '#fff',
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
    borderRadius: theme.spacing(2),
    padding: theme.spacing(2),
  },
  question: {
    marginBottom: theme.spacing(2),
    backgroundColor: '#fce4ec',
    padding: theme.spacing(2),
    borderRadius: theme.spacing(1),
    fontWeight: 'bold',
  },
  symptomsContainer: {
    marginBottom: theme.spacing(2),
  },
  symptoms: {
    backgroundColor: '#f3e5f5',
    padding: theme.spacing(1),
    borderRadius: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },
  optionsContainer: {
    marginBottom: theme.spacing(2),
  },
  optionButton: {
    marginRight: theme.spacing(2),
    marginBottom: theme.spacing(1),
    backgroundColor: '#f5f5f5',
    color: '#333',
    borderRadius: theme.spacing(1),
    textTransform: 'none',
    '&:hover': {
      backgroundColor: '#e0e0e0',
    },
  },
  nextButton: {
    marginTop: theme.spacing(2),
    textTransform: 'none',
    backgroundColor: '#5ddef4',
    color: '#fff',
    '&:hover': {
      backgroundColor: '#4ac1d1',
    },
  },
}));

const MentalHealth = () => {
  const classes = useStyles();
  const [question, setQuestion] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentQuestionId, setCurrentQuestionId] = useState(1);

  useEffect(() => {
    const fetchQuestion = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:5001/questions/${currentQuestionId}`);
        setQuestion(response.data);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchQuestion();
  }, [currentQuestionId]);

  const handleNextQuestion = () => {
    setCurrentQuestionId(currentQuestionId + 1);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className={classes.container}>
      <Card className={classes.card}>
        <CardContent>
          <Typography variant="h5" component="h2" className={classes.question}>
            {question.question}
          </Typography>
          <div className={classes.symptomsContainer}>
            <Typography variant="h6" component="h3">
              Symptoms:
            </Typography>
            <List>
              {question.symptoms.map((symptom, index) => (
                <ListItem key={index} className={classes.symptoms} variant="outlined">
                  <ListItemText primary={symptom} />
                </ListItem>
              ))}
            </List>
          </div>
          <div className={classes.optionsContainer}>
            <Typography variant="h6" component="h3">
              Options:
            </Typography>
            <Box mt={2}>
              {question.options.map((option, index) => (
                <Button
                  key={index}
                  variant="contained"
                  color="primary"
                  className={classes.optionButton}
                >
                  {option}
                </Button>
              ))}
            </Box>
          </div>
          <Button
            variant="contained"
            color="primary"
            className={classes.nextButton}
            onClick={handleNextQuestion}
          >
            Next
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default MentalHealth;

