import React from 'react'

function Community() {
  return (
    <div>Community</div>
  )
}

export default Community