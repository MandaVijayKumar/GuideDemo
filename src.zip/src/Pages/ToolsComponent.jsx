import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  toolsContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  },
  toolCard: {
    width: 300,
    margin: theme.spacing(2),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: theme.spacing(2),
    borderRadius: theme.spacing(1),
    transition: 'box-shadow 0.3s ease',
    backdropFilter: 'blur(10px)',
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.15)',
    cursor: 'pointer',
    '&:hover': {
      boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    },
  },
  toolTitle: {
    marginBottom: theme.spacing(2),
  },
}));

const ToolsComponent = () => {
  const classes = useStyles();
  const navigate = useNavigate();

  const handleExercise = () => {
    navigate('/psychoarea/exercise-selector');
  };

  const handleMoodTracker = () => {
    navigate('/psychoarea/moodtracker');
  };

  const handleNegativeThoughts = () => {
    navigate('/psychoarea/changethoughts');
  };

  return (
    <div className={classes.toolsContainer}>
      <Card className={classes.toolCard} variant="outlined" onClick={handleMoodTracker}>
        <CardContent>
          <Typography variant="h6" className={classes.toolTitle}>
            Mood Tracker
          </Typography>
          <Typography variant="body1">
            Track your mood and emotions to gain insights and self-awareness.
          </Typography>
        </CardContent>
      </Card>

      <Card className={classes.toolCard} variant="outlined" onClick={handleExercise}>
        <CardContent>
          <Typography variant="h6" className={classes.toolTitle}>
            Exercise Selector
          </Typography>
          <Typography variant="body1">
            Explore a variety of exercises and activities to promote well-being.
          </Typography>
        </CardContent>
      </Card>

      <Card className={classes.toolCard} variant="outlined" onClick={handleNegativeThoughts}>
        <CardContent>
          <Typography variant="h6" className={classes.toolTitle}>
            Change Negative Thoughts
          </Typography>
          <Typography variant="body1">
            Challenge and reframe negative thoughts for a positive mindset.
          </Typography>
        </CardContent>
      </Card>
    </div>
  );
};

export default ToolsComponent;

// import React from 'react';
// import { Card, CardContent, Typography } from '@mui/material';
// import { useNavigate } from 'react-router-dom';
// import { makeStyles } from '@material-ui/core/styles';

// const useStyles = makeStyles((theme) => ({
//   toolsContainer: {
//     display: 'flex',
//     justifyContent: 'center',
//     alignItems: 'center',
//     height: '100vh',
//   },
//   toolCard: {
//     width: 300,
//     margin: theme.spacing(2),
//     display: 'flex',
//     flexDirection: 'column',
//     alignItems: 'center',
//     padding: theme.spacing(2),
//     boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.15)',
//     borderRadius: theme.spacing(1),
//   },
//   toolTitle: {
//     marginBottom: theme.spacing(2),
//   },
// }));

// const ToolsComponent = () => {
//   const classes = useStyles();
//   const navigate = useNavigate();

//   const handleExercise = () => {
//     navigate('/psychoarea/exercise-selector');
//   };

//   const handleMoodTracker = () => {
//     navigate('/psychoarea/moodtracker');
//   };

//   const handleNegativeThoughts = () => {
//     navigate('/psychoarea/changethoughts');
//   };

//   return (
//     <div className={classes.toolsContainer}>
//       <Card className={classes.toolCard} variant="outlined" onClick={handleExercise}>
//         <CardContent>
//           <Typography variant="h6" className={classes.toolTitle}>
//             Mood Tracker
//           </Typography>
//           <Typography variant="body1">
//             Track your mood and emotions to gain insights and self-awareness.
//           </Typography>
//         </CardContent>
//       </Card>

//       <Card className={classes.toolCard} variant="outlined" onClick={handleMoodTracker}>
//         <CardContent>
//           <Typography variant="h6" className={classes.toolTitle}>
//             Exercise Selector
//           </Typography>
//           <Typography variant="body1">
//             Explore a variety of exercises and activities to promote well-being.
//           </Typography>
//         </CardContent>
//       </Card>

//       <Card className={classes.toolCard} variant="outlined" onClick={handleNegativeThoughts}>
//         <CardContent>
//           <Typography variant="h6" className={classes.toolTitle}>
//             Change Negative Thoughts
//           </Typography>
//           <Typography variant="body1">
//             Challenge and reframe negative thoughts for a positive mindset.
//           </Typography>
//         </CardContent>
//       </Card>
//     </div>
//   );
// };

// export default ToolsComponent;

// import React from 'react';
// import { Button } from '@mui/material';
// import { useNavigate } from 'react-router-dom';
// import { makeStyles } from '@material-ui/core/styles';


// const useStyles = makeStyles((theme) => ({
//   toolsContainer: {
//     display: 'flex',
//     justifyContent: 'center',
//     alignItems: 'center',
//     height: '100vh',
//   },
//   exerciseBtn: {
//     padding: '12px 24px',
//     fontSize: 16,
//     borderRadius: 8,
//   },
// }));

// const ToolsComponent = () => {
//   const classes = useStyles();
//   const navigate = useNavigate();

//   const handleExercise = () => {
//     navigate('/psychoarea/exercise-selector');
//   };
  
//   const handleMoodTracker = () => {
//     navigate('/psychoarea/moodtracker');
//   };
//   const handleNegativeThoughts = () => {
//     navigate('/psychoarea/changethoughts')
//   }
  

//   return (
//     <div className={classes.toolsContainer}>
//       <Button className={classes.exerciseBtn} variant="contained" onClick={handleMoodTracker}>
//        Mood Tracker
//       </Button>
//       <Button className={classes.exerciseBtn} variant="contained" onClick={handleExercise}>
//         Exercise Selector
//       </Button>
//       <Button className={classes.exerciseBtn} variant="contained" onClick={handleNegativeThoughts}>
//         Change Negative Thougths
//       </Button>
//     </div>
//   );
// };

// export default ToolsComponent;
